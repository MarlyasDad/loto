import sys
from loto.core import LotoGame, Config


def main():
    config = Config(sys.argv)
    # config.computers = 2
    # config.humans = 2
    game = LotoGame(config)
    game.run()


if __name__ == '__main__':
    main()
